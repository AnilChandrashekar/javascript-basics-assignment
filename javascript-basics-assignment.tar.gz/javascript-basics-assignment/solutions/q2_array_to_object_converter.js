

/* Write a Program to convert an array of objects to an object
	based on a given key */

// Function to fill the result object	
const fillResult = (keyName,key,arrItem,result) => {
		if(keyName===key)
		{  
			result[arrItem[key]]= arrItem ;
		}
};

// Function to convert array to object based on key passed.
const convert = (arr,key) => {
	let i;
	let k;
	let result = {};
	let keyNames;
	if(arr instanceof Array)
	{
		for ( i=0; i<arr.length; i+=1) 
		{
			keyNames = Object.keys(arr[i]);
			for( k=0;k<keyNames.length;k+=1)
			{
				fillResult(keyNames[k],key,arr[i],result);
			}
		}
	return result;
	}
	return null;
};


//
/* For example,
INPUT - convert([{id: 1, value: 'abc'}, {id: 2, value: 'xyz'}], 'id')
OUTPUT - {
			'1': {id: 1, value: 'abc'},
			'2': {id: 2, value: 'xyz'}
		 }
	
*/

module.exports = convert;

// console.log(convert([{id: 1, value: 'abc'}, {id: 2, value: 'xyz'}],'id'));
// console.log(convert([{ id: 1, name: 'Ankit', role: 'Developer'},
//  { id: 2, name: 'Pankhuri', role: 'Lead'},
//  { id: 3, name: 'Anubha', role: 'QA'}],'role'));
// console.log(convert('invalid value'));