// Create a list of fruits with their properties (name, color, pricePerKg)
// and convert it into a format so that for a given fruit name
// retrieval of its color and pricePerKg value is fast
// Write your code here

// Declare the list fo fruits
let fruitsList =[{ name:'Apple', color: 'Red', pricePerKg: 100},
                    { name:'Mango', color: 'Yellow', pricePerKg: 150},
                    { name:'Pomegranate', color: 'Pink', pricePerKg: 200}];

//Function to return color and price based on fruitname passed.
 const retrieval = (fruits,fruitName)=> {
    let colPrice;
    fruits.forEach(function (arrayItem) {
          if(arrayItem.name === fruitName)
        {
            colPrice = 'color: '+arrayItem.color + ' price:'+arrayItem.pricePerKg;
        }
    });
    return colPrice;
 };

 module.exports = retrieval;
 //Function call 
 console.log(retrieval(fruitsList,'Mango'));
 