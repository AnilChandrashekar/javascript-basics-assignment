// Write a program to display one result card of 100 students
// with their name and percentage
// Out of 100 students, 50 has subjects - Grammer and Accounts
// and other 50 has subjects -  Grammer and Physics

// Hint : You need to calculate percentage of 100 students having different set of subjects.
//        You can assume their scores on their respective subjects.


// Write your code here

// Preparing List of students
let studentList =[
    {name: 'Anil', Grammer: 80, Accounts: 75},
    {name: 'Sunil', Grammer: 80, Accounts: 77},
    {name: 'Akash', Grammer: 80, Accounts: 89},
    {name: 'Ansh', Grammer: 80, Accounts: 67},
    {name: 'Aksh', Grammer: 80, Accounts: 90},
    {name: 'Samar', Grammer: 80, Accounts: 67},
    {name: 'Girish', Grammer: 80, Accounts: 45},
    {name: 'Akki', Grammer: 80, Accounts: 90},
    {name: 'Samarpan', Grammer: 80, Accounts: 67},
    {name: 'Girisha', Grammer: 80, Accounts: 45},
    {name: 'Anil', Grammer: 80, Accounts: 75},
    {name: 'Sunil', Grammer: 80, Accounts: 77},
    {name: 'Akash', Grammer: 80, Accounts: 89},
    {name: 'Ansh', Grammer: 80, Accounts: 67},
    {name: 'Aksh', Grammer: 80, Accounts: 90},
    {name: 'Samar', Grammer: 80, Accounts: 67},
    {name: 'Girish', Grammer: 80, Accounts: 45},
    {name: 'Akki', Grammer: 80, Accounts: 90},
    {name: 'Samarpan', Grammer: 80, Accounts: 67},
    {name: 'Girisha', Grammer: 80, Accounts: 45},
    {name: 'Anil', Grammer: 80, Accounts: 75},
    {name: 'Sunil', Grammer: 80, Accounts: 77},
    {name: 'Akash', Grammer: 80, Accounts: 89},
    {name: 'Ansh', Grammer: 80, Accounts: 67},
    {name: 'Aksh', Grammer: 80, Accounts: 90},
    {name: 'Samar', Grammer: 80, Accounts: 67},
    {name: 'Girish', Grammer: 80, Accounts: 45},
    {name: 'Akki', Grammer: 80, Accounts: 90},
    {name: 'Samarpan', Grammer: 80, Accounts: 67},
    {name: 'Girisha', Grammer: 80, Accounts: 45},
    {name: 'Anil', Grammer: 80, Accounts: 75},
    {name: 'Sunil', Grammer: 80, Accounts: 77},
    {name: 'Akash', Grammer: 80, Accounts: 89},
    {name: 'Ansh', Grammer: 80, Accounts: 67},
    {name: 'Aksh', Grammer: 80, Accounts: 90},
    {name: 'Samar', Grammer: 80, Accounts: 67},
    {name: 'Girish', Grammer: 80, Accounts: 45},
    {name: 'Akki', Grammer: 80, Accounts: 90},
    {name: 'Samarpan', Grammer: 80, Accounts: 67},
    {name: 'Girisha', Grammer: 80, Accounts: 45},
    {name: 'Anil', Grammer: 80, Accounts: 75},
    {name: 'Sunil', Grammer: 80, Accounts: 77},
    {name: 'Akash', Grammer: 80, Accounts: 89},
    {name: 'Ansh', Grammer: 80, Accounts: 67},
    {name: 'Aksh', Grammer: 80, Accounts: 90},
    {name: 'Samar', Grammer: 80, Accounts: 67},
    {name: 'Girish', Grammer: 80, Accounts: 45},
    {name: 'Akki', Grammer: 80, Accounts: 90},
    {name: 'Samarpan', Grammer: 80, Accounts: 67},
    {name: 'Girisha', Grammer: 80, Accounts: 45},
    {name: 'Suresh', Grammer: 80, Physics: 56},
    {name: 'Samay', Grammer: 80, Physics: 67},
    {name: 'Anitha', Grammer: 80, Physics: 86},
    {name: 'Naveen', Grammer: 80, Physics: 56},
    {name: 'Hari', Grammer: 80, Physics: 89},
    {name: 'Abhishek', Grammer: 80, Physics: 76},
    {name: 'Abhilash', Grammer: 80, Physics: 78},
    {name: 'Abhishek kumar', Grammer: 80, Physics: 76},
    {name: 'kumar', Grammer: 80, Physics: 78},
    {name: 'kum', Grammer: 80, Physics: 78},
    {name: 'Suresh', Grammer: 80, Physics: 56},
    {name: 'Samay', Grammer: 80, Physics: 67},
    {name: 'Anitha', Grammer: 80, Physics: 86},
    {name: 'Naveen', Grammer: 80, Physics: 56},
    {name: 'Hari', Grammer: 80, Physics: 89},
    {name: 'Abhishek', Grammer: 80, Physics: 76},
    {name: 'Abhilash', Grammer: 80, Physics: 78},
    {name: 'Abhishek kumar', Grammer: 80, Physics: 76},
    {name: 'kumar', Grammer: 80, Physics: 78},
    {name: 'kum', Grammer: 80, Physics: 78},
    {name: 'Suresh', Grammer: 80, Physics: 56},
    {name: 'Samay', Grammer: 80, Physics: 67},
    {name: 'Anitha', Grammer: 80, Physics: 86},
    {name: 'Naveen', Grammer: 80, Physics: 56},
    {name: 'Hari', Grammer: 80, Physics: 89},
    {name: 'Abhishek', Grammer: 80, Physics: 76},
    {name: 'Abhilash', Grammer: 80, Physics: 78},
    {name: 'Abhishek kumar', Grammer: 80, Physics: 76},
    {name: 'kumar', Grammer: 80, Physics: 78},
    {name: 'kum', Grammer: 80, Physics: 78},
    {name: 'Suresh', Grammer: 80, Physics: 56},
    {name: 'Samay', Grammer: 80, Physics: 67},
    {name: 'Anitha', Grammer: 80, Physics: 86},
    {name: 'Naveen', Grammer: 80, Physics: 56},
    {name: 'Hari', Grammer: 80, Physics: 89},
    {name: 'Abhishek', Grammer: 80, Physics: 76},
    {name: 'Abhilash', Grammer: 80, Physics: 78},
    {name: 'Abhishek kumar', Grammer: 80, Physics: 76},
    {name: 'kumar', Grammer: 80, Physics: 78},
    {name: 'kum', Grammer: 80, Physics: 78},
    {name: 'Suresh', Grammer: 80, Physics: 56},
    {name: 'Samay', Grammer: 80, Physics: 67},
    {name: 'Anitha', Grammer: 80, Physics: 86},
    {name: 'Naveen', Grammer: 80, Physics: 56},
    {name: 'Hari', Grammer: 80, Physics: 89},
    {name: 'Abhishek', Grammer: 80, Physics: 76},
    {name: 'Abhilash', Grammer: 80, Physics: 78},
    {name: 'Abhishek kumar', Grammer: 80, Physics: 76},
    {name: 'kumar', Grammer: 80, Physics: 78},
    {name: 'kum', Grammer: 80, Physics: 78}];
// Function to print student name and percentage.    
const printPercent = (studentListItems)=> {
    console.log('Sl No'+'\t\t'+'Name'+'\t\t\t'+'Percentage');
    let slno =0;
    studentListItems.forEach(function (arrayItem) {
        let percentage = 0;
        if(!isNaN(arrayItem.Physics))
        {
            percentage = (arrayItem.Grammer+arrayItem.Physics)/2;
        }
        else if(!isNaN(arrayItem.Accounts))
        {
            percentage = (arrayItem.Grammer+arrayItem.Accounts)/2;
        }
        slno +=1;
       console.log(slno +'\t\t'+ arrayItem.name+'\t\t\t'+percentage);
    });
   };


module.exports = printPercent;
  
// Call function to print percentage
printPercent(studentList);


